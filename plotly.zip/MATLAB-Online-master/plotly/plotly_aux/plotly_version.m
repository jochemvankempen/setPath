function version = plotly_version()
    version = '2.2.9';
end
